import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET || "dev-secret-troque-em-producao";

if (!process.env.JWT_SECRET) {
  console.warn(
    "[auth] AVISO: JWT_SECRET não definido — usando um valor padrão inseguro. Defina JWT_SECRET em produção."
  );
}

export function signToken(user) {
  return jwt.sign({ userId: user.id, username: user.username }, JWT_SECRET, {
    expiresIn: "30d",
  });
}

export function verifyToken(token) {
  return jwt.verify(token, JWT_SECRET);
}

// Middleware para rotas REST que exigem login.
export function authMiddleware(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "Não autenticado" });

  try {
    const payload = verifyToken(token);
    req.userId = payload.userId;
    req.username = payload.username;
    next();
  } catch {
    return res.status(401).json({ error: "Token inválido ou expirado" });
  }
}
