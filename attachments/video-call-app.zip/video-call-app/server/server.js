import { createServer } from "http";
import express from "express";
import cors from "cors";
import bcrypt from "bcryptjs";
import { Server } from "socket.io";
import { pool, initDb } from "./db.js";
import { signToken, verifyToken, authMiddleware } from "./auth.js";

const PORT = process.env.PORT || 3001;

// Em produção, defina ALLOWED_ORIGIN com o domínio do seu front-end
// (ex: https://meu-app.vercel.app). Se não definir, libera geral (bom
// só para testes locais).
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || "*";

const app = express();
app.use(cors({ origin: ALLOWED_ORIGIN }));
app.use(express.json());

const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: { origin: ALLOWED_ORIGIN },
});

/* ========================================================================
   PRESENÇA ONLINE (em memória — reinicia se o servidor reiniciar)
   ======================================================================== */

// userId -> Set<socketId>  (um usuário pode ter várias abas/dispositivos)
const onlineUsers = new Map();

function isOnline(userId) {
  return onlineUsers.has(userId);
}

function addOnline(userId, socketId) {
  if (!onlineUsers.has(userId)) onlineUsers.set(userId, new Set());
  onlineUsers.get(userId).add(socketId);
}

// Retorna true se o usuário ficou totalmente offline (sem nenhuma aba aberta)
function removeOnline(userId, socketId) {
  const set = onlineUsers.get(userId);
  if (!set) return true;
  set.delete(socketId);
  if (set.size === 0) {
    onlineUsers.delete(userId);
    return true;
  }
  return false;
}

function emitToUser(userId, event, payload) {
  const set = onlineUsers.get(userId);
  if (!set) return;
  set.forEach((socketId) => io.to(socketId).emit(event, payload));
}

async function getFriendIds(userId) {
  const result = await pool.query(
    `SELECT CASE WHEN requester_id = $1 THEN addressee_id ELSE requester_id END AS friend_id
     FROM friendships
     WHERE (requester_id = $1 OR addressee_id = $1) AND status = 'accepted'`,
    [userId]
  );
  return result.rows.map((r) => r.friend_id);
}

/* ========================================================================
   REST — AUTENTICAÇÃO
   ======================================================================== */

const USERNAME_RE = /^[a-zA-Z0-9_]{3,20}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

app.post("/api/auth/register", async (req, res) => {
  const { username, email, password } = req.body || {};

  if (!username || !email || !password) {
    return res.status(400).json({ error: "Preencha usuário, email e senha" });
  }
  if (!USERNAME_RE.test(username)) {
    return res
      .status(400)
      .json({ error: "Usuário deve ter 3-20 caracteres: letras, números ou _" });
  }
  if (!EMAIL_RE.test(email)) {
    return res.status(400).json({ error: "Email inválido" });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: "Senha deve ter ao menos 6 caracteres" });
  }

  try {
    const passwordHash = await bcrypt.hash(password, 10);
    const result = await pool.query(
      "INSERT INTO users (username, email, password_hash) VALUES ($1, $2, $3) RETURNING id, username",
      [username, email.toLowerCase(), passwordHash]
    );
    const user = result.rows[0];
    const token = signToken(user);
    res.json({ token, user: { id: user.id, username: user.username } });
  } catch (err) {
    if (err.code === "23505") {
      return res.status(409).json({ error: "Usuário ou email já cadastrado" });
    }
    console.error(err);
    res.status(500).json({ error: "Erro ao criar conta" });
  }
});

app.post("/api/auth/login", async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) {
    return res.status(400).json({ error: "Preencha email e senha" });
  }

  try {
    const result = await pool.query("SELECT * FROM users WHERE email = $1", [
      email.toLowerCase(),
    ]);
    const user = result.rows[0];
    if (!user) return res.status(401).json({ error: "Email ou senha incorretos" });

    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: "Email ou senha incorretos" });

    const token = signToken(user);
    res.json({ token, user: { id: user.id, username: user.username } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Erro ao entrar" });
  }
});

app.get("/api/me", authMiddleware, (req, res) => {
  res.json({ id: req.userId, username: req.username });
});

/* ========================================================================
   REST — AMIGOS
   ======================================================================== */

app.post("/api/friends/request", authMiddleware, async (req, res) => {
  const { username } = req.body || {};
  if (!username) return res.status(400).json({ error: "Informe um nome de usuário" });

  try {
    const targetResult = await pool.query(
      "SELECT id, username FROM users WHERE LOWER(username) = LOWER($1)",
      [username]
    );
    const target = targetResult.rows[0];
    if (!target) return res.status(404).json({ error: "Usuário não encontrado" });
    if (target.id === req.userId) {
      return res.status(400).json({ error: "Você não pode adicionar a si mesmo" });
    }

    const existing = await pool.query(
      `SELECT * FROM friendships
       WHERE (requester_id = $1 AND addressee_id = $2) OR (requester_id = $2 AND addressee_id = $1)`,
      [req.userId, target.id]
    );
    if (existing.rows.length > 0) {
      const status = existing.rows[0].status;
      return res.status(409).json({
        error: status === "accepted" ? "Vocês já são amigos" : "Já existe um pedido pendente",
      });
    }

    await pool.query(
      "INSERT INTO friendships (requester_id, addressee_id, status) VALUES ($1, $2, 'pending')",
      [req.userId, target.id]
    );

    emitToUser(target.id, "friend-request", { fromUsername: req.username });
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Erro ao enviar pedido de amizade" });
  }
});

app.post("/api/friends/respond", authMiddleware, async (req, res) => {
  const { requesterUsername, accept } = req.body || {};
  if (!requesterUsername) return res.status(400).json({ error: "Requisição inválida" });

  try {
    const requesterResult = await pool.query(
      "SELECT id, username FROM users WHERE LOWER(username) = LOWER($1)",
      [requesterUsername]
    );
    const requester = requesterResult.rows[0];
    if (!requester) return res.status(404).json({ error: "Usuário não encontrado" });

    const pending = await pool.query(
      "SELECT * FROM friendships WHERE requester_id = $1 AND addressee_id = $2 AND status = 'pending'",
      [requester.id, req.userId]
    );
    if (pending.rows.length === 0) {
      return res.status(404).json({ error: "Pedido não encontrado" });
    }

    if (accept) {
      await pool.query("UPDATE friendships SET status = 'accepted' WHERE id = $1", [
        pending.rows[0].id,
      ]);
      emitToUser(requester.id, "friend-request-accepted", { byUsername: req.username });
    } else {
      await pool.query("DELETE FROM friendships WHERE id = $1", [pending.rows[0].id]);
    }

    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Erro ao responder pedido de amizade" });
  }
});

app.get("/api/friends", authMiddleware, async (req, res) => {
  try {
    const accepted = await pool.query(
      `SELECT u.id, u.username FROM friendships f
       JOIN users u ON u.id = CASE WHEN f.requester_id = $1 THEN f.addressee_id ELSE f.requester_id END
       WHERE (f.requester_id = $1 OR f.addressee_id = $1) AND f.status = 'accepted'`,
      [req.userId]
    );
    const incoming = await pool.query(
      `SELECT u.username FROM friendships f
       JOIN users u ON u.id = f.requester_id
       WHERE f.addressee_id = $1 AND f.status = 'pending'`,
      [req.userId]
    );
    const outgoing = await pool.query(
      `SELECT u.username FROM friendships f
       JOIN users u ON u.id = f.addressee_id
       WHERE f.requester_id = $1 AND f.status = 'pending'`,
      [req.userId]
    );

    res.json({
      friends: accepted.rows.map((r) => ({ id: r.id, username: r.username, online: isOnline(r.id) })),
      incomingRequests: incoming.rows.map((r) => r.username),
      outgoingRequests: outgoing.rows.map((r) => r.username),
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Erro ao carregar amigos" });
  }
});

/* ========================================================================
   REST — HISTÓRICO DE CHAT PRIVADO
   ======================================================================== */

app.get("/api/messages/:username", authMiddleware, async (req, res) => {
  try {
    const friendResult = await pool.query(
      "SELECT id FROM users WHERE LOWER(username) = LOWER($1)",
      [req.params.username]
    );
    const friend = friendResult.rows[0];
    if (!friend) return res.status(404).json({ error: "Usuário não encontrado" });

    const friendship = await pool.query(
      `SELECT 1 FROM friendships
       WHERE status = 'accepted'
       AND ((requester_id = $1 AND addressee_id = $2) OR (requester_id = $2 AND addressee_id = $1))`,
      [req.userId, friend.id]
    );
    if (friendship.rows.length === 0) {
      return res.status(403).json({ error: "Vocês não são amigos" });
    }

    const messages = await pool.query(
      `SELECT sender_id, content, created_at FROM messages
       WHERE (sender_id = $1 AND receiver_id = $2) OR (sender_id = $2 AND receiver_id = $1)
       ORDER BY created_at ASC LIMIT 300`,
      [req.userId, friend.id]
    );

    res.json({
      messages: messages.rows.map((m) => ({
        fromMe: m.sender_id === req.userId,
        text: m.content,
        time: m.created_at,
      })),
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Erro ao carregar mensagens" });
  }
});

/* ========================================================================
   SOCKET.IO — sinalização de chamada (anônima) + amigos/chat (autenticado)
   ======================================================================== */

// roomId -> Set<socketId>  (salas de chamada por código, sem login)
const rooms = new Map();

function leaveRoom(socket) {
  const roomId = socket.data.roomId;
  if (!roomId) return;

  const room = rooms.get(roomId);
  if (room) {
    room.delete(socket.id);
    if (room.size === 0) rooms.delete(roomId);
  }

  socket.to(roomId).emit("user-left", { userId: socket.id });
  socket.leave(roomId);
  socket.data.roomId = null;
}

// Autenticação OPCIONAL no socket: se vier um token válido, o socket fica
// "logado" (habilita amigos/chat privado/convite de chamada). Sem token,
// ou com token inválido, o socket continua funcionando normalmente para
// chamadas anônimas por código de sala.
io.use((socket, next) => {
  const token = socket.handshake.auth?.token;
  if (token) {
    try {
      const payload = verifyToken(token);
      socket.data.userId = payload.userId;
      socket.data.username = payload.username;
    } catch {
      // token inválido/expirado — segue como anônimo, não bloqueia a conexão
    }
  }
  next();
});

io.on("connection", async (socket) => {
  const who = socket.data.username ? ` (${socket.data.username})` : "";
  console.log(`[conectado] ${socket.id}${who}`);

  if (socket.data.userId) {
    addOnline(socket.data.userId, socket.id);
    try {
      const friendIds = await getFriendIds(socket.data.userId);
      friendIds.forEach((fid) => emitToUser(fid, "friend-online", { userId: socket.data.userId }));
    } catch (err) {
      console.error(err);
    }
  }

  // ---- chamada por código de sala (funciona com ou sem login) ----
  socket.on("join-room", (roomId) => {
    if (!roomId || typeof roomId !== "string") return;

    const room = rooms.get(roomId) || new Set();
    if (room.size >= 2) {
      socket.emit("room-full", { roomId });
      return;
    }

    const otherUsers = Array.from(room);
    room.add(socket.id);
    rooms.set(roomId, room);

    socket.join(roomId);
    socket.data.roomId = roomId;

    socket.emit("joined", { roomId, otherUsers });
    socket.to(roomId).emit("user-joined", { userId: socket.id });
  });

  socket.on("signal", ({ to, data }) => {
    if (!to || !data) return;
    io.to(to).emit("signal", { from: socket.id, data });
  });

  socket.on("leave-room", () => {
    leaveRoom(socket);
  });

  // ---- chat privado (exige login) ----
  socket.on("private-message", async ({ toUsername, text }) => {
    if (!socket.data.userId || !toUsername || !text) return;

    try {
      const targetResult = await pool.query(
        "SELECT id FROM users WHERE LOWER(username) = LOWER($1)",
        [toUsername]
      );
      const target = targetResult.rows[0];
      if (!target) return;

      const friendship = await pool.query(
        `SELECT 1 FROM friendships WHERE status = 'accepted'
         AND ((requester_id = $1 AND addressee_id = $2) OR (requester_id = $2 AND addressee_id = $1))`,
        [socket.data.userId, target.id]
      );
      if (friendship.rows.length === 0) return;

      const inserted = await pool.query(
        "INSERT INTO messages (sender_id, receiver_id, content) VALUES ($1, $2, $3) RETURNING created_at",
        [socket.data.userId, target.id, text]
      );

      emitToUser(target.id, "private-message", {
        fromUsername: socket.data.username,
        text,
        time: inserted.rows[0].created_at,
      });
    } catch (err) {
      console.error(err);
    }
  });

  // ---- convite de chamada de vídeo pra um amigo (exige login) ----
  socket.on("call-invite", async ({ toUsername, roomId }) => {
    if (!socket.data.userId || !toUsername || !roomId) return;

    try {
      const targetResult = await pool.query(
        "SELECT id FROM users WHERE LOWER(username) = LOWER($1)",
        [toUsername]
      );
      const target = targetResult.rows[0];
      if (!target) return;

      emitToUser(target.id, "call-invite", { fromUsername: socket.data.username, roomId });
    } catch (err) {
      console.error(err);
    }
  });

  socket.on("disconnect", async () => {
    console.log(`[desconectado] ${socket.id}`);
    leaveRoom(socket);

    if (socket.data.userId) {
      const wentOffline = removeOnline(socket.data.userId, socket.id);
      if (wentOffline) {
        try {
          const friendIds = await getFriendIds(socket.data.userId);
          friendIds.forEach((fid) =>
            emitToUser(fid, "friend-offline", { userId: socket.data.userId })
          );
        } catch (err) {
          console.error(err);
        }
      }
    }
  });
});

/* ========================================================================
   BOOT
   ======================================================================== */

async function start() {
  try {
    await initDb();
  } catch (err) {
    console.error("[db] falha ao inicializar o banco de dados:", err.message);
    console.error("Verifique se DATABASE_URL está configurado corretamente.");
    process.exit(1);
  }

  httpServer.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
  });
}

start();
