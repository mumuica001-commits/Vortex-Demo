import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Proxy do socket.io para o servidor Node, para que o navegador só precise
// falar com UMA origem (a do Vite). Isso evita problemas de mixed-content
// quando o app é acessado via HTTPS (necessário para câmera/microfone
// em dispositivos que não sejam localhost).
export default defineConfig({
  plugins: [react()],
  server: {
    host: true, // permite acesso pela rede local (0.0.0.0)
    port: 5173,
    proxy: {
      "/socket.io": {
        target: "http://localhost:3001",
        ws: true,
        changeOrigin: true,
      },
    },
  },
});
