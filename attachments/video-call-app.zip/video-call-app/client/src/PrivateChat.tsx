import { useEffect, useRef, useState } from "react";
import { PrivateMessageRecord } from "./api";

interface Props {
  friendUsername: string;
  messages: PrivateMessageRecord[];
  onSend: (text: string) => void;
  onClose: () => void;
}

function formatTime(ts: string | number): string {
  return new Date(ts).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
}

export default function PrivateChat({ friendUsername, messages, onSend, onClose }: Props) {
  const [input, setInput] = useState("");
  const endRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const text = input.trim();
    if (!text) return;
    onSend(text);
    setInput("");
  }

  return (
    <div className="private-chat">
      <div className="private-chat-header">
        <span>@{friendUsername}</span>
        <button className="chat-close" onClick={onClose}>
          ✕
        </button>
      </div>

      <div className="private-chat-messages">
        {messages.length === 0 && (
          <p className="chat-empty">Nenhuma mensagem ainda. Diga oi!</p>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`chat-msg ${m.fromMe ? "me" : "remote"}`}>
            <span className="chat-text">{m.text}</span>
            <span className="chat-time">{formatTime(m.time)}</span>
          </div>
        ))}
        <div ref={endRef} />
      </div>

      <form className="chat-input-row" onSubmit={handleSubmit}>
        <input
          placeholder="Digite uma mensagem..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />
        <button type="submit">Enviar</button>
      </form>
    </div>
  );
}
