const API_URL = import.meta.env.VITE_SERVER_URL || "";
const TOKEN_KEY = "vortex_token";

export interface AuthUser {
  id: number;
  username: string;
}

export interface FriendEntry {
  id: number;
  username: string;
  online: boolean;
}

export interface PrivateMessageRecord {
  fromMe: boolean;
  text: string;
  time: string | number;
}

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function saveToken(token: string) {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearToken() {
  localStorage.removeItem(TOKEN_KEY);
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...((options.headers as Record<string, string>) || {}),
  };
  if (token) headers["Authorization"] = `Bearer ${token}`;

  const res = await fetch(`${API_URL}${path}`, { ...options, headers });
  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new Error(data.error || "Erro na requisição");
  }
  return data as T;
}

export const api = {
  register: (username: string, email: string, password: string) =>
    request<{ token: string; user: AuthUser }>("/api/auth/register", {
      method: "POST",
      body: JSON.stringify({ username, email, password }),
    }),

  login: (email: string, password: string) =>
    request<{ token: string; user: AuthUser }>("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    }),

  me: () => request<{ id: number; username: string; email: string }>("/api/me"),

  getFriends: () =>
    request<{
      friends: FriendEntry[];
      incomingRequests: string[];
      outgoingRequests: string[];
    }>("/api/friends"),

  requestFriend: (username: string) =>
    request<{ ok: true }>("/api/friends/request", {
      method: "POST",
      body: JSON.stringify({ username }),
    }),

  respondFriend: (requesterUsername: string, accept: boolean) =>
    request<{ ok: true }>("/api/friends/respond", {
      method: "POST",
      body: JSON.stringify({ requesterUsername, accept }),
    }),

  getMessages: (username: string) =>
    request<{ messages: PrivateMessageRecord[] }>(
      `/api/messages/${encodeURIComponent(username)}`
    ),
};
