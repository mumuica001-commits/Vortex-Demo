import { useState } from "react";
import { FriendEntry } from "./api";

interface Props {
  myUsername: string;
  friends: FriendEntry[];
  incomingRequests: string[];
  outgoingRequests: string[];
  selectedFriend: string | null;
  unreadFriends: Record<string, number>;
  onSelectFriend: (username: string) => void;
  onAddFriend: (username: string) => Promise<void>;
  onRespond: (username: string, accept: boolean) => Promise<void>;
  onCallFriend: (username: string) => void;
  onLogout: () => void;
}

export default function FriendsSidebar(props: Props) {
  const [addInput, setAddInput] = useState("");
  const [addError, setAddError] = useState<string | null>(null);
  const [addLoading, setAddLoading] = useState(false);

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    const username = addInput.trim();
    if (!username) return;

    setAddError(null);
    setAddLoading(true);
    try {
      await props.onAddFriend(username);
      setAddInput("");
    } catch (err) {
      setAddError(err instanceof Error ? err.message : "Erro ao adicionar");
    } finally {
      setAddLoading(false);
    }
  }

  return (
    <div className="friends-sidebar">
      <div className="sidebar-header">
        <span className="my-username">@{props.myUsername}</span>
        <button className="logout-btn" onClick={props.onLogout} title="Sair da conta">
          Sair
        </button>
      </div>

      <form className="add-friend-row" onSubmit={handleAdd}>
        <input
          placeholder="Adicionar por usuário"
          value={addInput}
          onChange={(e) => setAddInput(e.target.value)}
        />
        <button type="submit" disabled={addLoading}>
          +
        </button>
      </form>
      {addError && <p className="add-friend-error">{addError}</p>}

      {props.incomingRequests.length > 0 && (
        <div className="friend-requests">
          <p className="section-title">Pedidos recebidos</p>
          {props.incomingRequests.map((username) => (
            <div key={username} className="request-row">
              <span>@{username}</span>
              <div className="request-actions">
                <button onClick={() => props.onRespond(username, true)} title="Aceitar">
                  ✓
                </button>
                <button onClick={() => props.onRespond(username, false)} title="Recusar">
                  ✕
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {props.outgoingRequests.length > 0 && (
        <div className="friend-requests">
          <p className="section-title">Pedidos enviados</p>
          {props.outgoingRequests.map((username) => (
            <div key={username} className="request-row pending">
              <span>@{username}</span>
              <span className="pending-label">pendente</span>
            </div>
          ))}
        </div>
      )}

      <p className="section-title">Amigos ({props.friends.length})</p>
      <div className="friends-list">
        {props.friends.length === 0 && (
          <p className="friends-empty">Adicione alguém pelo nome de usuário.</p>
        )}
        {props.friends.map((friend) => (
          <div
            key={friend.id}
            className={`friend-row ${props.selectedFriend === friend.username ? "selected" : ""}`}
            onClick={() => props.onSelectFriend(friend.username)}
          >
            <span className={`status-dot ${friend.online ? "online" : "offline"}`} />
            <span className="friend-name">@{friend.username}</span>
            {props.unreadFriends[friend.username] > 0 && (
              <span className="badge">{props.unreadFriends[friend.username]}</span>
            )}
            <button
              className="call-friend-btn"
              onClick={(e) => {
                e.stopPropagation();
                props.onCallFriend(friend.username);
              }}
              disabled={!friend.online}
              title={friend.online ? "Chamar por vídeo" : "Offline"}
            >
              📹
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
