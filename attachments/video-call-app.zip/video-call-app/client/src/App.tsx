import { useEffect, useRef, useState } from "react";
import { io, Socket } from "socket.io-client";
import {
  api,
  getToken,
  clearToken,
  AuthUser,
  FriendEntry,
  PrivateMessageRecord,
} from "./api";
import AuthScreen from "./AuthScreen";
import FriendsSidebar from "./FriendsSidebar";
import PrivateChat from "./PrivateChat";

const ICE_SERVERS: RTCConfiguration = {
  iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
};

// Em dev local, deixamos em branco e o Vite faz proxy de /socket.io
// (veja vite.config.ts). Em produção (ex: client na Vercel), defina
// VITE_SERVER_URL no .env com a URL pública do servidor.
const SERVER_URL = import.meta.env.VITE_SERVER_URL || "";

interface SignalPayload {
  from: string;
  data: RTCSessionDescriptionInit | { type: "candidate"; candidate: RTCIceCandidateInit };
}

interface CallChatMessage {
  sender: "me" | "remote";
  text: string;
  time: number;
}

interface IncomingCall {
  fromUsername: string;
  roomId: string;
}

function generateRoomId(): string {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}

function formatTime(ts: number): string {
  return new Date(ts).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
}

export default function App() {
  /* ---------------- Autenticação ---------------- */
  const [authChecking, setAuthChecking] = useState<boolean>(!!getToken());
  const [currentUser, setCurrentUser] = useState<AuthUser | null>(null);
  const [guestMode, setGuestMode] = useState(false);

  /* ---------------- Amigos ---------------- */
  const [friends, setFriends] = useState<FriendEntry[]>([]);
  const [incomingRequests, setIncomingRequests] = useState<string[]>([]);
  const [outgoingRequests, setOutgoingRequests] = useState<string[]>([]);
  const [selectedFriendChat, setSelectedFriendChat] = useState<string | null>(null);
  const [privateMessages, setPrivateMessages] = useState<Record<string, PrivateMessageRecord[]>>(
    {}
  );
  const [unreadFriends, setUnreadFriends] = useState<Record<string, number>>({});
  const [incomingCall, setIncomingCall] = useState<IncomingCall | null>(null);

  /* ---------------- Chamada (código de sala) ---------------- */
  const [roomInput, setRoomInput] = useState("");
  const [currentRoom, setCurrentRoom] = useState<string | null>(null);
  const [micOn, setMicOn] = useState(true);
  const [camOn, setCamOn] = useState(true);
  const [status, setStatus] = useState("Desconectado");
  const [remoteConnected, setRemoteConnected] = useState(false);
  const [callActive, setCallActive] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [callMessages, setCallMessages] = useState<CallChatMessage[]>([]);
  const [callChatInput, setCallChatInput] = useState("");
  const [callUnreadCount, setCallUnreadCount] = useState(0);
  const [copied, setCopied] = useState(false);

  const socketRef = useRef<Socket | null>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const remoteSocketIdRef = useRef<string | null>(null);
  const pendingCandidatesRef = useRef<RTCIceCandidateInit[]>([]);
  const dataChannelRef = useRef<RTCDataChannel | null>(null);
  const selectedFriendRef = useRef<string | null>(null);

  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);
  const stageRef = useRef<HTMLDivElement | null>(null);
  const callChatEndRef = useRef<HTMLDivElement | null>(null);

  /* ======================== Autenticação inicial ======================== */

  useEffect(() => {
    const token = getToken();
    if (!token) {
      setAuthChecking(false);
      return;
    }
    api
      .me()
      .then((me) => setCurrentUser({ id: me.id, username: me.username }))
      .catch(() => clearToken())
      .finally(() => setAuthChecking(false));
  }, []);

  useEffect(() => {
    selectedFriendRef.current = selectedFriendChat;
  }, [selectedFriendChat]);

  /* ======================== Socket.IO ======================== */

  useEffect(() => {
    if (authChecking) return;
    if (!currentUser && !guestMode) return;

    const token = getToken();
    const socket = io(SERVER_URL, {
      path: "/socket.io",
      auth: token ? { token } : {},
    });
    socketRef.current = socket;

    socket.on("connect", () => setStatus("Conectado ao servidor de sinalização"));

    // ---- chamada por código de sala ----
    socket.on("joined", async ({ otherUsers }: { roomId: string; otherUsers: string[] }) => {
      if (otherUsers.length > 0) {
        remoteSocketIdRef.current = otherUsers[0];
        setStatus("Conectando com o outro participante...");
        await startCallAsInitiator();
      } else {
        setStatus("Aguardando o outro participante entrar na sala...");
      }
    });

    socket.on("user-joined", ({ userId }: { userId: string }) => {
      remoteSocketIdRef.current = userId;
      setStatus("Outro participante entrou. Aguardando conexão...");
    });

    socket.on("signal", async ({ from, data }: SignalPayload) => {
      remoteSocketIdRef.current = from;
      const pc = pcRef.current ?? createPeerConnection(false);

      if ("type" in data && data.type === "offer") {
        const stream = await getLocalStream();
        stream.getTracks().forEach((track) => pc.addTrack(track, stream));

        await pc.setRemoteDescription(new RTCSessionDescription(data));
        await flushPendingCandidates(pc);

        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);

        socket.emit("signal", { to: from, data: pc.localDescription });
      } else if ("type" in data && data.type === "answer") {
        await pc.setRemoteDescription(new RTCSessionDescription(data));
        await flushPendingCandidates(pc);
      } else if ("type" in data && data.type === "candidate") {
        const candidate = (data as { candidate: RTCIceCandidateInit }).candidate;
        if (pc.remoteDescription && pc.remoteDescription.type) {
          await pc.addIceCandidate(new RTCIceCandidate(candidate));
        } else {
          pendingCandidatesRef.current.push(candidate);
        }
      }
    });

    socket.on("room-full", () => {
      setStatus("Essa sala já tem 2 participantes. Crie ou use outra sala.");
    });

    socket.on("user-left", () => {
      setStatus("O outro participante saiu da chamada.");
      teardownPeerConnection();
    });

    // ---- amigos (só relevante se autenticado) ----
    socket.on("friend-request", () => refreshFriends());
    socket.on("friend-request-accepted", () => refreshFriends());
    socket.on("friend-online", () => refreshFriends());
    socket.on("friend-offline", () => refreshFriends());

    socket.on(
      "private-message",
      (msg: { fromUsername: string; text: string; time: string }) => {
        setPrivateMessages((prev) => {
          const list = prev[msg.fromUsername] || [];
          return {
            ...prev,
            [msg.fromUsername]: [...list, { fromMe: false, text: msg.text, time: msg.time }],
          };
        });
        if (selectedFriendRef.current !== msg.fromUsername) {
          setUnreadFriends((prev) => ({
            ...prev,
            [msg.fromUsername]: (prev[msg.fromUsername] || 0) + 1,
          }));
        }
      }
    );

    socket.on("call-invite", ({ fromUsername, roomId }: IncomingCall) => {
      setIncomingCall({ fromUsername, roomId });
    });

    if (currentUser) refreshFriends();

    return () => {
      socket.disconnect();
      socketRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authChecking, currentUser, guestMode]);

  useEffect(() => {
    return () => {
      cleanupEverything();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    callChatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [callMessages, chatOpen]);

  useEffect(() => {
    if (chatOpen) setCallUnreadCount(0);
  }, [chatOpen, callMessages]);

  useEffect(() => {
    const handler = () => {
      if (!document.fullscreenElement) setIsFullscreen(false);
    };
    document.addEventListener("fullscreenchange", handler);
    return () => document.removeEventListener("fullscreenchange", handler);
  }, []);

  /* ======================== Amigos ======================== */

  async function refreshFriends() {
    if (!getToken()) return;
    try {
      const data = await api.getFriends();
      setFriends(data.friends);
      setIncomingRequests(data.incomingRequests);
      setOutgoingRequests(data.outgoingRequests);
    } catch {
      // falha temporária — ignora, tenta de novo no próximo evento
    }
  }

  async function handleAddFriend(username: string) {
    await api.requestFriend(username);
    await refreshFriends();
  }

  async function handleRespondFriend(username: string, accept: boolean) {
    await api.respondFriend(username, accept);
    await refreshFriends();
  }

  async function handleSelectFriend(username: string) {
    setSelectedFriendChat(username);
    setUnreadFriends((prev) => ({ ...prev, [username]: 0 }));
    if (!privateMessages[username]) {
      try {
        const data = await api.getMessages(username);
        setPrivateMessages((prev) => ({ ...prev, [username]: data.messages }));
      } catch {
        // ignora
      }
    }
  }

  function handleSendPrivateMessage(toUsername: string, text: string) {
    socketRef.current?.emit("private-message", { toUsername, text });
    setPrivateMessages((prev) => {
      const list = prev[toUsername] || [];
      return { ...prev, [toUsername]: [...list, { fromMe: true, text, time: Date.now() }] };
    });
  }

  function handleCallFriend(username: string) {
    const roomId = generateRoomId();
    socketRef.current?.emit("call-invite", { toUsername: username, roomId });
    setSelectedFriendChat(null);
    joinRoom(roomId);
  }

  function handleAcceptIncomingCall() {
    if (!incomingCall) return;
    setSelectedFriendChat(null);
    joinRoom(incomingCall.roomId);
    setIncomingCall(null);
  }

  function handleRejectIncomingCall() {
    setIncomingCall(null);
  }

  function handleLogout() {
    clearToken();
    handleEndCall();
    setCurrentUser(null);
    setGuestMode(false);
    setFriends([]);
    setIncomingRequests([]);
    setOutgoingRequests([]);
    setSelectedFriendChat(null);
    setPrivateMessages({});
    setUnreadFriends({});
    setIncomingCall(null);
  }

  /* ======================== WebRTC (chamada) ======================== */

  async function getLocalStream(): Promise<MediaStream> {
    if (localStreamRef.current) return localStreamRef.current;
    const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    localStreamRef.current = stream;
    if (localVideoRef.current) localVideoRef.current.srcObject = stream;
    return stream;
  }

  function setupDataChannel(channel: RTCDataChannel) {
    dataChannelRef.current = channel;
    channel.onmessage = (event) => {
      try {
        const parsed = JSON.parse(event.data) as { text: string };
        addCallMessage("remote", parsed.text);
      } catch {
        // ignora mensagens malformadas
      }
    };
    channel.onclose = () => {
      if (dataChannelRef.current === channel) dataChannelRef.current = null;
    };
  }

  function addCallMessage(sender: "me" | "remote", text: string) {
    setCallMessages((prev) => [...prev, { sender, text, time: Date.now() }]);
    if (sender === "remote") setCallUnreadCount((c) => c + 1);
  }

  function createPeerConnection(isInitiator: boolean): RTCPeerConnection {
    const pc = new RTCPeerConnection(ICE_SERVERS);

    if (isInitiator) {
      setupDataChannel(pc.createDataChannel("chat"));
    } else {
      pc.ondatachannel = (event) => setupDataChannel(event.channel);
    }

    pc.onicecandidate = (event) => {
      if (event.candidate && remoteSocketIdRef.current) {
        socketRef.current?.emit("signal", {
          to: remoteSocketIdRef.current,
          data: { type: "candidate", candidate: event.candidate.toJSON() },
        });
      }
    };

    pc.ontrack = (event) => {
      if (remoteVideoRef.current) remoteVideoRef.current.srcObject = event.streams[0];
      setRemoteConnected(true);
    };

    pc.onconnectionstatechange = () => {
      setStatus(`Estado da conexão: ${pc.connectionState}`);
      if (["disconnected", "failed", "closed"].includes(pc.connectionState)) {
        setRemoteConnected(false);
      }
    };

    pcRef.current = pc;
    setCallActive(true);
    return pc;
  }

  async function flushPendingCandidates(pc: RTCPeerConnection) {
    for (const candidate of pendingCandidatesRef.current) {
      await pc.addIceCandidate(new RTCIceCandidate(candidate));
    }
    pendingCandidatesRef.current = [];
  }

  async function startCallAsInitiator() {
    const pc = createPeerConnection(true);
    const stream = await getLocalStream();
    stream.getTracks().forEach((track) => pc.addTrack(track, stream));

    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);

    socketRef.current?.emit("signal", {
      to: remoteSocketIdRef.current,
      data: pc.localDescription,
    });
  }

  async function joinRoom(roomId: string) {
    await getLocalStream();
    setCurrentRoom(roomId);

    const socket = socketRef.current;
    if (!socket) return;

    if (socket.connected) {
      socket.emit("join-room", roomId);
    } else {
      socket.once("connect", () => socket.emit("join-room", roomId));
    }
  }

  async function handleCreateRoom() {
    const id = generateRoomId();
    setRoomInput(id);
    setSelectedFriendChat(null);
    await joinRoom(id);
  }

  async function handleJoinRoom() {
    const id = roomInput.trim().toUpperCase();
    if (!id) return;
    setSelectedFriendChat(null);
    await joinRoom(id);
  }

  function toggleMic() {
    const stream = localStreamRef.current;
    if (!stream) return;
    const nextEnabled = !micOn;
    stream.getAudioTracks().forEach((track) => (track.enabled = nextEnabled));
    setMicOn(nextEnabled);
  }

  function toggleCam() {
    const stream = localStreamRef.current;
    if (!stream || isScreenSharing) return;
    const nextEnabled = !camOn;
    stream.getVideoTracks().forEach((track) => (track.enabled = nextEnabled));
    setCamOn(nextEnabled);
  }

  async function startScreenShare() {
    const pc = pcRef.current;
    if (!pc) return;
    try {
      const screenStream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: false,
      });
      const screenTrack = screenStream.getVideoTracks()[0];
      screenStreamRef.current = screenStream;

      const sender = pc.getSenders().find((s) => s.track?.kind === "video");
      if (sender) await sender.replaceTrack(screenTrack);
      if (localVideoRef.current) localVideoRef.current.srcObject = screenStream;

      screenTrack.onended = () => stopScreenShare();
      setIsScreenSharing(true);
    } catch {
      // usuário cancelou a seleção de tela
    }
  }

  async function stopScreenShare() {
    const pc = pcRef.current;
    const cameraStream = localStreamRef.current;

    if (pc && cameraStream) {
      const camTrack = cameraStream.getVideoTracks()[0];
      const sender = pc.getSenders().find((s) => s.track?.kind === "video");
      if (sender && camTrack) await sender.replaceTrack(camTrack);
    }
    if (localVideoRef.current && cameraStream) localVideoRef.current.srcObject = cameraStream;

    screenStreamRef.current?.getTracks().forEach((track) => track.stop());
    screenStreamRef.current = null;
    setIsScreenSharing(false);
  }

  function toggleScreenShare() {
    if (isScreenSharing) stopScreenShare();
    else startScreenShare();
  }

  function toggleFullscreen() {
    setIsFullscreen((prev) => {
      const next = !prev;
      try {
        if (next) {
          stageRef.current?.requestFullscreen?.().catch(() => {});
        } else if (document.fullscreenElement) {
          document.exitFullscreen?.().catch(() => {});
        }
      } catch {
        // Fullscreen API indisponível — o layout já cobre a tela via CSS
      }
      return next;
    });
  }

  function handleSendCallChat(e: React.FormEvent) {
    e.preventDefault();
    const text = callChatInput.trim();
    if (!text) return;
    const channel = dataChannelRef.current;
    if (channel && channel.readyState === "open") {
      channel.send(JSON.stringify({ text }));
      addCallMessage("me", text);
      setCallChatInput("");
    }
  }

  async function copyRoomCode() {
    if (!currentRoom) return;
    try {
      await navigator.clipboard.writeText(currentRoom);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      // clipboard indisponível
    }
  }

  function teardownPeerConnection() {
    pcRef.current?.close();
    pcRef.current = null;
    dataChannelRef.current = null;
    remoteSocketIdRef.current = null;
    pendingCandidatesRef.current = [];
    if (remoteVideoRef.current) remoteVideoRef.current.srcObject = null;
    screenStreamRef.current?.getTracks().forEach((track) => track.stop());
    screenStreamRef.current = null;
    setIsScreenSharing(false);
    setRemoteConnected(false);
    setCallActive(false);
  }

  function cleanupEverything() {
    teardownPeerConnection();
    localStreamRef.current?.getTracks().forEach((track) => track.stop());
    localStreamRef.current = null;
  }

  function handleEndCall() {
    socketRef.current?.emit("leave-room");
    cleanupEverything();
    setCurrentRoom(null);
    setStatus("Chamada encerrada");
    setCallMessages([]);
    setChatOpen(false);
    setCallChatInput("");
    setIsFullscreen(false);
    if (document.fullscreenElement) document.exitFullscreen?.().catch(() => {});
    if (localVideoRef.current) localVideoRef.current.srcObject = null;
  }

  /* ======================== Render ======================== */

  if (authChecking) {
    return (
      <div className="app">
        <h1>Vortex</h1>
        <p className="status">Carregando...</p>
      </div>
    );
  }

  if (!currentUser && !guestMode) {
    return (
      <AuthScreen
        onAuthenticated={(user) => setCurrentUser(user)}
        onSkip={() => setGuestMode(true)}
      />
    );
  }

  return (
    <div className="app-shell">
      {currentUser && (
        <FriendsSidebar
          myUsername={currentUser.username}
          friends={friends}
          incomingRequests={incomingRequests}
          outgoingRequests={outgoingRequests}
          selectedFriend={selectedFriendChat}
          unreadFriends={unreadFriends}
          onSelectFriend={handleSelectFriend}
          onAddFriend={handleAddFriend}
          onRespond={handleRespondFriend}
          onCallFriend={handleCallFriend}
          onLogout={handleLogout}
        />
      )}

      <div className="app main-area">
        <h1>Vortex</h1>
        <p className="status">{status}</p>

        {incomingCall && (
          <div className="incoming-call-banner">
            <span>📹 @{incomingCall.fromUsername} está te chamando</span>
            <div className="incoming-call-actions">
              <button onClick={handleAcceptIncomingCall}>Aceitar</button>
              <button className="end-call" onClick={handleRejectIncomingCall}>
                Recusar
              </button>
            </div>
          </div>
        )}

        {!currentRoom && !selectedFriendChat && (
          <div className="pre-call">
            <button onClick={handleCreateRoom}>Criar sala</button>
            <div className="join-row">
              <input
                placeholder="Código da sala"
                value={roomInput}
                onChange={(e) => setRoomInput(e.target.value)}
              />
              <button onClick={handleJoinRoom}>Entrar na sala</button>
            </div>
          </div>
        )}

        {!currentRoom && selectedFriendChat && (
          <PrivateChat
            friendUsername={selectedFriendChat}
            messages={privateMessages[selectedFriendChat] || []}
            onSend={(text) => handleSendPrivateMessage(selectedFriendChat, text)}
            onClose={() => setSelectedFriendChat(null)}
          />
        )}

        {currentRoom && (
          <p className="room-info">
            Sala: <strong>{currentRoom}</strong>
            <button className="copy-btn" onClick={copyRoomCode} title="Copiar código">
              {copied ? "Copiado!" : "Copiar"}
            </button>
            {!remoteConnected && <span> — compartilhe esse código com a outra pessoa</span>}
          </p>
        )}

        {currentRoom && (
          <div ref={stageRef} className={`call-stage ${isFullscreen ? "fullscreen" : ""}`}>
            <video
              ref={remoteVideoRef}
              autoPlay
              playsInline
              className={remoteConnected ? "video-main" : "video-hidden"}
            />
            <video
              ref={localVideoRef}
              autoPlay
              playsInline
              muted
              className={remoteConnected ? "video-pip" : "video-main"}
            />

            {!remoteConnected && (
              <div className="waiting-overlay">
                <span>Aguardando o outro participante entrar na sala...</span>
              </div>
            )}

            <span className={`video-label ${remoteConnected ? "label-pip" : "label-main"}`}>
              Você{isScreenSharing ? " (compartilhando tela)" : ""}
            </span>
            {remoteConnected && <span className="video-label label-remote">Remoto</span>}

            {chatOpen && (
              <div className="chat-panel">
                <div className="chat-header">
                  <span>Chat da chamada</span>
                  <button className="chat-close" onClick={() => setChatOpen(false)}>
                    ✕
                  </button>
                </div>
                <div className="chat-messages">
                  {callMessages.length === 0 && (
                    <p className="chat-empty">Nenhuma mensagem ainda. Diga oi!</p>
                  )}
                  {callMessages.map((m, i) => (
                    <div key={i} className={`chat-msg ${m.sender}`}>
                      <span className="chat-text">{m.text}</span>
                      <span className="chat-time">{formatTime(m.time)}</span>
                    </div>
                  ))}
                  <div ref={callChatEndRef} />
                </div>
                <form className="chat-input-row" onSubmit={handleSendCallChat}>
                  <input
                    placeholder="Digite uma mensagem..."
                    value={callChatInput}
                    onChange={(e) => setCallChatInput(e.target.value)}
                    disabled={!remoteConnected}
                  />
                  <button type="submit" disabled={!remoteConnected}>
                    Enviar
                  </button>
                </form>
              </div>
            )}

            <div className="call-controls floating">
              <button onClick={toggleMic} title="Microfone">
                {micOn ? "🎤" : "🔇"}
              </button>
              <button onClick={toggleCam} disabled={isScreenSharing} title="Câmera">
                {camOn ? "📹" : "🚫"}
              </button>
              <button
                onClick={toggleScreenShare}
                disabled={!callActive}
                title="Compartilhar tela"
                className={isScreenSharing ? "active-toggle" : ""}
              >
                🖥️
              </button>
              <button className="chat-toggle" onClick={() => setChatOpen((o) => !o)} title="Chat">
                💬
                {callUnreadCount > 0 && !chatOpen && (
                  <span className="badge">{callUnreadCount}</span>
                )}
              </button>
              <button onClick={toggleFullscreen} title="Tela cheia">
                {isFullscreen ? "🡼" : "⛶"}
              </button>
              <button className="end-call" onClick={handleEndCall} title="Encerrar chamada">
                📞
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
